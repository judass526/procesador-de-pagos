import unittest
from unittest.mock import Mock
from src.interfaces import PaymentGateway, TransactionRepository
from src.payment_processor import PaymentError, PaymentProcessor
from tests.fakes import InMemoryTransactionRepository

class ProcessorTestCase(unittest.TestCase):
    def setUp(self):
        self.gateway = Mock(spec=PaymentGateway)
        self.repo = Mock(spec=TransactionRepository)
        self.processor = PaymentProcessor(self.gateway, self.repo)

class TestValidation(ProcessorTestCase):
    def test_zero_amount_is_rejected_without_gateway_call(self):
        with self.assertRaises(ValueError): self.processor.pay("cliente-1", 0)
        self.gateway.charge.assert_not_called()
    def test_negative_amount_is_rejected_without_gateway_call(self):
        with self.assertRaises(ValueError): self.processor.pay("cliente-1", -50)
        self.gateway.charge.assert_not_called()

class TestApprovedPayment(ProcessorTestCase):
    def test_returns_approved_result_and_id(self):
        self.gateway.charge.return_value = {"status":"approved", "id":"tx-1"}
        result = self.processor.pay("cliente-1", 100)
        self.assertTrue(result.approved)
        self.assertEqual(result.transaction_id, "tx-1")
    def test_charges_and_saves_once(self):
        self.gateway.charge.return_value = {"status":"approved", "id":"tx-1"}
        self.processor.pay("cliente-1", 100)
        self.gateway.charge.assert_called_once_with("cliente-1", 100)
        self.repo.save.assert_called_once()

class TestDeclinedPayment(ProcessorTestCase):
    def setUp(self):
        super().setUp()
        self.gateway.charge.return_value = {"status":"declined", "id":None}
    def test_returns_not_approved(self):
        result = self.processor.pay("cliente-1", 100)
        self.assertFalse(result.approved)
        self.assertIsNone(result.transaction_id)
    def test_does_not_save_declined_payment(self):
        self.processor.pay("cliente-1", 100)
        self.repo.save.assert_not_called()

class TestGatewayFailure(ProcessorTestCase):
    def setUp(self):
        super().setUp()
        self.gateway.charge.side_effect = ConnectionError("timeout")
    def test_translates_connection_error(self):
        with self.assertRaises(PaymentError): self.processor.pay("cliente-1", 100)
    def test_does_not_save_on_gateway_failure(self):
        with self.assertRaises(PaymentError): self.processor.pay("cliente-1", 100)
        self.repo.save.assert_not_called()

class TestRepositoryFake(unittest.TestCase):
    def test_only_approved_payments_are_stored(self):
        gateway = Mock(spec=PaymentGateway)
        repo = InMemoryTransactionRepository()
        processor = PaymentProcessor(gateway, repo)
        gateway.charge.side_effect = [
            {"status":"approved", "id":"tx-1"},
            {"status":"declined", "id":None},
            {"status":"approved", "id":"tx-3"}]
        for _ in range(3): processor.pay("cliente-1", 100)
        self.assertEqual([t.transaction_id for t in repo.items], ["tx-1", "tx-3"])

class TestManualReview(ProcessorTestCase):
    def test_amount_above_limit_is_pending_without_charge(self):
        result = self.processor.pay("cliente-1", 10000.01)
        self.assertEqual(result.status, "pending_review")
        self.assertFalse(result.approved)
        self.gateway.charge.assert_not_called()
        self.repo.save.assert_called_once_with(result)
    def test_exact_limit_is_charged(self):
        self.gateway.charge.return_value = {"status":"approved", "id":"tx-9"}
        result = self.processor.pay("cliente-1", 10000)
        self.assertEqual(result.status, "approved")
        self.gateway.charge.assert_called_once_with("cliente-1", 10000)

if __name__ == "__main__": unittest.main()
