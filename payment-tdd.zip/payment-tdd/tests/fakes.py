from src.interfaces import TransactionRepository

class InMemoryTransactionRepository(TransactionRepository):
    """Fake repository storing transactions in memory."""
    def __init__(self) -> None:
        self.items = []

    def save(self, transaction) -> None:
        self.items.append(transaction)
