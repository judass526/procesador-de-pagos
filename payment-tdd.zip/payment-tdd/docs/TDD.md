# TDD, dobles y regresión

## Requisitos extraídos

- RF-01: importes menores o iguales a cero causan `ValueError` y no llaman a la pasarela.
- RF-02/03: un pago aprobado devuelve su id y se persiste.
- RF-04: un rechazo devuelve no aprobado y no se persiste.
- RF-05: `ConnectionError` se convierte en `PaymentError`; no se persiste.
- RF-06: solo importes estrictamente superiores a 10,000 pasan a revisión manual y se guardan; exactamente 10,000 se cobra.

## Ciclos Red → Green → Refactor

1. Validación: pruebas de cero y negativo; validación mínima antes de invocar la pasarela.
2. Aprobación: stub `return_value`, verificación de llamada mock; cobro y persistencia.
3. Rechazo: una prueba expone que no debe guardarse; guardar solo aprobados.
4. Fallo: mock con `side_effect=ConnectionError`; traducir a error de dominio.
5. Refactor: contratos, tipado, resultado inmutable, `Mock(spec=...)` y fake de repositorio.
6. Regresión: el PDF reporta pruebas de 10,000 y 10,000.01, una regresión de tres errores cuando se quitó `approved`, y la reparación con propiedad compatible derivada de `status`.

La suite entregada tiene 11 pruebas. El relato de las fases históricas y su salida proviene del PDF; no se presentan como ejecuciones o commits realizados durante la creación de este paquete.

## Dobles de prueba

- Stub: `return_value` para controlar las respuestas del gateway.
- Mock: aserciones de interacción y `side_effect` para simular caída de red.
- Fake: `InMemoryTransactionRepository` para comprobar estado final.
- `spec`: limita mocks a los contratos definidos.

## Límites

No hay adaptadores reales de red o base de datos. La actividad reconoce `float` como simplificación y sugiere `Decimal`/Money para uso real; no se extiende el alcance del taller.
