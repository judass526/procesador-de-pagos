from abc import ABC, abstractmethod

class PaymentGateway(ABC):
    @abstractmethod
    def charge(self, customer_id: str, amount: float) -> dict:
        """Return a gateway status and transaction id."""

class TransactionRepository(ABC):
    @abstractmethod
    def save(self, transaction) -> None:
        """Persist a payment result."""
