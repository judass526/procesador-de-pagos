from dataclasses import dataclass
from src.interfaces import PaymentGateway, TransactionRepository

MANUAL_REVIEW_LIMIT = 10_000

class PaymentError(Exception):
    """Domain error raised when the payment gateway cannot be reached."""

@dataclass(frozen=True)
class PaymentResult:
    status: str
    transaction_id: str | None

    @property
    def approved(self) -> bool:
        return self.status == "approved"

class PaymentProcessor:
    def __init__(self, gateway: PaymentGateway, repository: TransactionRepository) -> None:
        self._gateway = gateway
        self._repository = repository

    def pay(self, customer_id: str, amount: float) -> PaymentResult:
        self._validate(amount)
        if amount > MANUAL_REVIEW_LIMIT:
            pending = PaymentResult("pending_review", None)
            self._repository.save(pending)
            return pending
        try:
            response = self._gateway.charge(customer_id, amount)
        except ConnectionError as exc:
            raise PaymentError("No se pudo contactar la pasarela") from exc
        result = PaymentResult(response["status"], response["id"])
        if result.approved:
            self._repository.save(result)
        return result

    @staticmethod
    def _validate(amount: float) -> None:
        if amount <= 0:
            raise ValueError("El monto debe ser mayor a cero")
