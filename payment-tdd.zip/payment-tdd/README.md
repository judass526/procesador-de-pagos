# payment-tdd

Procesador de pagos en Python descrito por la Actividad 10 adjunta. Valida montos, delega a una pasarela abstracta, guarda pagos aprobados, traduce errores de conexión y deja montos superiores a 10,000 en `pending_review`. No conecta servicios reales.

## Requisitos y uso

Python 3.12. No requiere dependencias externas. Desde la raíz:

```bash
python --version
python -m unittest discover -s tests -t . -v
```

Con `pytest` instalado también puede ejecutarse `pytest -v`.

## Carpetas

- `src/`: contratos y lógica de pagos.
- `tests/`: 11 pruebas unitarias y fake de repositorio.
- `docs/`: informe, TDD y documento fuente.
- `screenshots/`: exactamente dos imágenes ilustrativas.

El recorrido Red/Green/Refactor, los doubles y la regresión están documentados en `docs/TDD.md`. El PDF adjunto reporta ejecuciones históricas; las ilustraciones de este paquete no son evidencia de ejecuciones reales. Ejecuta la suite localmente para producir tus propias capturas.

## GitHub y Moodle

1. Crea en GitHub un repositorio vacío llamado `payment-tdd`.
2. En esta carpeta: `git init`, `git add .`, `git commit -m "feat: entrega inicial payment-tdd"`.
3. Conecta la URL del repositorio: `git remote add origin URL`; sube con `git branch -M main` y `git push -u origin main`.
4. Completa tus datos en el informe y entrega en Moodle el enlace y el ZIP. La actividad pide historial TDD y evidencia reproducida; adjunta tu propio historial/capturas tras correrlo.
